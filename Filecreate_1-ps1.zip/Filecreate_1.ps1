﻿configuration createFile
    {
    param
    (
        [string[]]$computerName
    )
    Node $computerName
       
        {
          File CreateFile {
            Type = 'Directory'
            DestinationPath = 'C:\Ratheesh'
            Ensure = "Present"
            }
        }
    }